# Nightfall Client — Fabric 1.21.11

A small client-side Fabric mod project with a configurable on-screen module list and keybind toggles. The included movement modules are intended for single-player worlds or servers where client-side modifications are permitted.

## Modules / default binds

| Module | Default key | Function |
|---|---:|---|
| Speed | V | Modest movement boost while moving |
| Bunny Hop | B | Automatically jumps while moving on the ground |
| Target Bot | G | Selects the nearest living entity and turns toward it |
| Kill Aura | H | Attacks a nearby target automatically |
| HUD | Right Shift | Show/hide the Nightfall overlay |

The HUD shows enabled modules and the current target. The project is a starting point: ESP rendering is not enabled in this build, because the world-render API changed across recent Fabric versions.

## Build on GitHub

1. Create a GitHub repository and upload the contents of this ZIP.
2. Open **Actions** and allow workflows if GitHub asks.
3. The workflow builds the mod and attaches `nightfall-client-1.0.0.jar` to the workflow run as an artifact.
4. Download the artifact, then place the JAR in your Minecraft `mods` folder. Install Fabric Loader for Minecraft 1.21.11 and a compatible Fabric API.

You can also build locally with JDK 21 and Gradle 8.14.3:

```bash
gradle build
```

The output JAR is in `build/libs/`.

## Notes

- This repository contains source code and a GitHub Actions build workflow; it does not include a prebuilt JAR.
- Use only in single-player or multiplayer environments that permit client mods.
- Minecraft/Fabric APIs can change. If a build fails, check the Actions log and update the pinned dependency versions to the latest compatible 1.21.11 versions.
