package dj.nightfall;

import dj.nightfall.module.NightfallModules;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class NightfallClient implements ClientModInitializer {
    private static KeyBinding speedKey;
    private static KeyBinding bunnyKey;
    private static KeyBinding targetKey;
    private static KeyBinding auraKey;
    private static KeyBinding hudKey;
    private static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of("nightfall", "main"));
    private static boolean hudVisible = true;
    private static int tickCounter = 0;

    @Override
    public void onInitializeClient() {
        NightfallModules.init();
        speedKey = bind("Speed", GLFW.GLFW_KEY_V);
        bunnyKey = bind("Bunny Hop", GLFW.GLFW_KEY_B);
        targetKey = bind("Target Bot", GLFW.GLFW_KEY_G);
        auraKey = bind("Kill Aura", GLFW.GLFW_KEY_H);
        hudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nightfall.toggle_hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (speedKey.wasPressed()) NightfallModules.SPEED.toggle();
            while (bunnyKey.wasPressed()) NightfallModules.BUNNY_HOP.toggle();
            while (targetKey.wasPressed()) NightfallModules.TARGET_BOT.toggle();
            while (auraKey.wasPressed()) NightfallModules.KILL_AURA.toggle();
            while (hudKey.wasPressed()) hudVisible = !hudVisible;

            if (++tickCounter >= 2) {
                tickCounter = 0;
                NightfallModules.tick(client);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> renderHud(drawContext));
    }

    private static KeyBinding bind(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nightfall." + name.toLowerCase().replace(' ', '_'),
                InputUtil.Type.KEYSYM, key, CATEGORY));
    }

    private static void renderHud(DrawContext ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!hudVisible || client.player == null) return;

        int x = 8;
        int y = 8;
        ctx.fill(x - 4, y - 4, x + 142, y + 57, 0xB9121624);
        ctx.fill(x - 4, y - 4, x + 142, y - 2, 0xFF8B5CF6);
        ctx.drawTextWithShadow(client.textRenderer, "N I G H T F A L L", x, y, 0xFFE8E7FF);
        y += 13;
        ctx.drawTextWithShadow(client.textRenderer, "V Speed  " + state(NightfallModules.SPEED.isEnabled()), x, y, color(NightfallModules.SPEED.isEnabled()));
        y += 10;
        ctx.drawTextWithShadow(client.textRenderer, "B Bunny Hop  " + state(NightfallModules.BUNNY_HOP.isEnabled()), x, y, color(NightfallModules.BUNNY_HOP.isEnabled()));
        y += 10;
        ctx.drawTextWithShadow(client.textRenderer, "G Target Bot  " + state(NightfallModules.TARGET_BOT.isEnabled()), x, y, color(NightfallModules.TARGET_BOT.isEnabled()));
        y += 10;
        ctx.drawTextWithShadow(client.textRenderer, "H Kill Aura  " + state(NightfallModules.KILL_AURA.isEnabled()), x, y, color(NightfallModules.KILL_AURA.isEnabled()));
        if (NightfallModules.currentTargetName() != null) {
            ctx.drawTextWithShadow(client.textRenderer, "Target: " + NightfallModules.currentTargetName(), x, y + 11, 0xFFFFC857);
        }
    }

    private static String state(boolean enabled) { return enabled ? "ON" : "OFF"; }
    private static int color(boolean enabled) { return enabled ? 0xFF6EE7B7 : 0xFF9CA3AF; }
}
