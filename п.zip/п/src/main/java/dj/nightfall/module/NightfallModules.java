package dj.nightfall.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class NightfallModules {
    public static final ToggleModule SPEED = new ToggleModule("Speed");
    public static final ToggleModule BUNNY_HOP = new ToggleModule("Bunny Hop");
    public static final ToggleModule TARGET_BOT = new ToggleModule("Target Bot");
    public static final ToggleModule KILL_AURA = new ToggleModule("Kill Aura");

    private static LivingEntity currentTarget;
    private static int auraCooldown;

    private NightfallModules() {}

    public static void init() {}

    public static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            currentTarget = null;
            return;
        }

        var player = client.player;

        if (SPEED.isEnabled() && player.isOnGround() && client.options.forwardKey.isPressed()) {
            Vec3d velocity = player.getVelocity();
            player.setVelocity(velocity.x * 1.12, velocity.y, velocity.z * 1.12);
        }

        if (BUNNY_HOP.isEnabled() && player.isOnGround()
                && (client.options.forwardKey.isPressed() || (client.options.leftKey.isPressed() || client.options.rightKey.isPressed()))) {
            player.jump();
        }

        currentTarget = null;
        if (TARGET_BOT.isEnabled() || KILL_AURA.isEnabled()) {
            double bestDistance = KILL_AURA.isEnabled() ? 4.2 : 6.0;
            for (LivingEntity entity : client.world.getEntitiesByClass(
                    LivingEntity.class, player.getBoundingBox().expand(6.0),
                    e -> e != player && e.isAlive() && !(e instanceof PlayerEntity p && p.isSpectator()))) {
                double distance = player.squaredDistanceTo(entity);
                if (distance <= bestDistance * bestDistance) {
                    bestDistance = Math.sqrt(distance);
                    currentTarget = entity;
                }
            }
        }

        if (TARGET_BOT.isEnabled() && currentTarget != null) {
            aimAt(player.getX(), player.getEyeY(), player.getZ(), currentTarget, client);
        }

        if (KILL_AURA.isEnabled() && currentTarget != null && auraCooldown-- <= 0) {
            if (player.getAttackCooldownProgress(0.0F) >= 0.9F) {
                client.interactionManager.attackEntity(player, currentTarget);
                player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
                auraCooldown = 10;
            }
        }
        if (auraCooldown < 0) auraCooldown = 0;
    }

    private static void aimAt(double x, double eyeY, double z, LivingEntity target, MinecraftClient client) {
        var player = client.player;
        double dx = target.getX() - x;
        double dy = target.getEyeY() - eyeY;
        double dz = target.getZ() - z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
        float pitch = (float) (-(MathHelper.atan2(dy, horizontal) * 180.0 / Math.PI));
        player.setYaw(yaw);
        player.setPitch(MathHelper.clamp(pitch, -90.0F, 90.0F));
    }

    public static String currentTargetName() {
        return currentTarget == null ? null : currentTarget.getName().getString();
    }
}
