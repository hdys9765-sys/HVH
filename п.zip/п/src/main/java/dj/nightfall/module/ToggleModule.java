package dj.nightfall.module;

public final class ToggleModule {
    private final String name;
    private boolean enabled;

    public ToggleModule(String name) {
        this.name = name;
    }

    public String name() { return name; }
    public boolean isEnabled() { return enabled; }
    public void toggle() { enabled = !enabled; }
    public void setEnabled(boolean value) { enabled = value; }
}
